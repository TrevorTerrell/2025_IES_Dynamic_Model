%% Data Acqusition
%%%
powers = readmatrix('powers.csv');
%%%
poweruse = readmatrix('poweruse.csv');
%%%
hitec_temps = readmatrix('hitec_temps.csv');
%%%
core_temps = readmatrix('core_temps.csv');
%%%
feedbacks = readmatrix('feedbacks.csv');
%%%
secondary_temps = readmatrix('secondary_temps.csv');
%%%
% poisons = readmatrix('poisons.csv');
% %%%
% turbines = readmatrix('turbines.csv');
%%%
plp = readmatrix('plp.csv');
%%%
%% Graph Setup
zeroStamp = 5000;
start_plot = -500;
plot_width = 60*60; 
stop_plot = zeroStamp + plot_width;
time_step = 500;

x0=10;
y0=10;
width=1050;
height=650;
% width=700;
% height=600;
% width=950;
% height=1000;
nom_power = 1200;

% plot_choice = 0; % 0 for Power, 1 for Temps, 2 for Feedbacks, 3 for Xenon, 4 for Samarium, 5 for Turbines
plot_choice = 1; % 0 for Power, 1 for Temps, 2 for Feedbacks, 3 for PLP

time_unit = 0; % 0 for seconds, 1 for minutes, 2 for hours, 3 for days

if time_unit == 0 
    time_conv = 1;
end
if time_unit == 1
    time_conv = 60;
end
if time_unit == 2 
    time_conv = 3600;
end
if time_unit == 3
    time_conv = 86400;
end

%% Powers Graph
%subplot(2,1,1);
if plot_choice == 0
% set(gcf, 'position',[x0,y0,width,height]);
plot(((powers(:,1)-zeroStamp)/time_conv), powers(:,2)*nom_power, 'color', '#A2142F', 'linestyle', '-', 'linewidth', 1.0); % Total
hold on
plot(((powers(:,1)-zeroStamp)/time_conv), powers(:,3)*nom_power, 'color', '#0072BD', 'linewidth', 1.0); % Fission
hold on
plot(((powers(:,1)-zeroStamp)/time_conv), powers(:,4)*nom_power, 'color', '#2A292A', 'linewidth', 1.0); % Decay
hold on
%
plot(((poweruse(:,1)-zeroStamp)/time_conv), poweruse(:,3), 'color', 'red', 'LineStyle', '--', 'linewidth', 1.0); % HyS
hold on 
plot(((poweruse(:,1)-zeroStamp)/time_conv), poweruse(:,2), 'color', 'blue', 'LineStyle', '--', 'linewidth', 1.0); % OTSG
hold on 

title('Thermal Power Production and Usage')
lgd = legend('Total Power', 'Fission Power', 'Decay Power', 'HyS Usage', 'OTSG Usage');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
% ylim([0 1400]);
% yticks(0:200:1400);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Power (MW_{th})');
grid on

%% Loop Temperatures Graph
%subplot(2,1,2);
elseif plot_choice == 1
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,2), 'color', '#0072BD', 'linestyle', '-', 'linewidth', 1.0); % Core Inlet
hold on 
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,3), 'color', '#A2142F', 'linestyle', '-', 'linewidth', 1.0); % Core Outlet
hold on 
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,4), 'color', '#2A292A', 'linestyle', ':', 'linewidth', 1.5); % Reflector
hold on 
plot(((secondary_temps(:,1)-zeroStamp)/time_conv), secondary_temps(:,2), 'color', '#A2142F', 'linestyle', '--', 'linewidth', 1.0); % PHX secondary
hold on 
plot(((secondary_temps(:,1)-zeroStamp)/time_conv), secondary_temps(:,3), 'color', '#0072BD', 'linestyle', '--', 'linewidth', 1.0); % SHX primary
hold on 
% plot(((hitec_temps(:,1)-zeroStamp)/time_conv), hitec_temps(:,2), 'color', '#2A292A', 'linestyle', '-.', 'linewidth', 1.2); % SHX
% hold on 
% plot(((hitec_temps(:,1)-zeroStamp)/time_conv), hitec_temps(:,3), 'color', '#0072BD', 'linestyle', '--', 'linewidth', 1.0); % OTSG
% hold on 
% plot(((hitec_temps(:,1)-zeroStamp)/time_conv), hitec_temps(:,4), 'color', '#A2142F', 'linestyle', '--', 'linewidth', 1.0); % HyS
% hold on 
% ~~~
% y1 = yline(523, '-', 'Primary Salt Freeze', 'LineWidth', 1);
% hold on 
% y1.LabelHorizontalAlignment = 'center';
% y1.LabelVerticalAlignment = 'middle';
% y1.FontSize = 9;
% hold on 
y2 = yline(512.8, '--', 'Secondary Salt Freeze', 'LineWidth', 1);
hold on 
y2.LabelHorizontalAlignment = 'center';
y2.LabelVerticalAlignment = 'middle';
y2.FontSize = 9;
% yline(142)
% hold on 

title('Primary and Secondary Loop Temperatures')
lgd = legend('Core Inlet', 'Core Outlet', 'Reflector', 'PHX Secondary Side', 'SHX Primary Side');
%lgd = legend('Core Inlet', 'Core Outlet', 'Reflector', 'SHX', 'OTSG', 'HyS');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
ylim([400 800]);
% yticks(560:20:740);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Temperature ({\circ}C)');
grid on


%% Reactivity Graph
%subplot(2,2,1);
elseif plot_choice == 2
plot(((feedbacks(:,1)-zeroStamp)/time_conv), 1e5*(feedbacks(:,2) + feedbacks(:,3)), 'color', '#A2142F', 'linestyle', '-', 'linewidth', 1.0); % Fuel Temp
hold on
plot(((feedbacks(:,1)-zeroStamp)/time_conv), 1e5*feedbacks(:,4), 'color', '#0072BD', 'linestyle', '--', 'linewidth', 1.1); % Reflector
hold on 
plot(((feedbacks(:,1)-zeroStamp)/time_conv), 1e5*feedbacks(:,5), 'color', '#EDB120', 'linestyle', '--', 'linewidth', 1.1); % Poisons
hold on 
% plot(((feedbacks(:,1)-zeroStamp)/time_conv), 1e5*feedbacks(:,6), 'color', '#2A292A', 'linestyle', '-', 'linewidth', 1.0); % External
% hold on 
plot(((feedbacks(:,1)-zeroStamp)/time_conv), 1e5*feedbacks(:,7), 'color', '#2A292A', 'linestyle', ':', 'linewidth', 1.5); % Total
hold on 

title('Reactivity Effects')
% lgd = legend('Fuel Temp', 'Reflector', 'Poisons', 'External', 'Total');
lgd = legend('Fuel Temp', 'Reflector', 'Poisons', 'Total');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
% ylim([-250 250]);
% yticks(-250:50:250);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Reactivity (pcm)');
grid on

%sgtitle('100pcm Insertion - Modelica')

%% Pump Flow Coastdown Graph
%subplot(2,1,2);
elseif plot_choice == 3
plot(((plp(:,1)-zeroStamp)/time_conv), plp(:,2), 'color', 'b', 'linewidth', 1.0); 
hold on 

title('Primary Loop Flow Fraction')
%lgd = legend('Inlet', 'Outlet', 'Reflector');
% xlim([(start_plot/time_conv) (plot_width/time_conv)]);
% xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
% ylim([660 740]);
% yticks(660:20:740);
xlim([-10 100]);
xticks(-10:10:100);
ylim([0 1.1]);
yticks(0:0.1:1.1);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Flow Fraction (1/nominal)');
grid on

%% Core Temperatures Graph
%subplot(2,1,2);
elseif plot_choice == 31
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,2), 'color', 'b', 'linewidth', 1.0); % Core Inlet
hold on 
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,3), 'color', 'r', 'linewidth', 1.0); % Core Outlet
hold on 
plot(((core_temps(:,1)-zeroStamp)/time_conv), core_temps(:,4), 'color', 'g', 'linewidth', 1.0); % Reflector
hold on 

title('Core Temperatures')
lgd = legend('Inlet', 'Outlet', 'Reflector');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
ylim([660 740]);
yticks(660:20:740);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Temperature ({\circ}C)');
grid on

%% Xenon Graph
%subplot(2,2,2);
elseif plot_choice == 30
yyaxis left
plot(((poisons(:,1)-zeroStamp)/time_conv), (poisons(:,2)/poisons(2,2)-0.00016), 'color', '#1772e8', 'linewidth', 1.0); % Xe conc
hold on
% plot(((poisons(:,1)-zeroStamp)/time_conv), (poisons(:,3)/poisons(2,3)), 'color', '#1772e8', 'linewidth', 1.0); % Sm conc
% hold on 
yyaxis right
plot(((poisons(:,1)-zeroStamp)/time_conv), 1e-5*(poisons(:,4)/poisons(2,4)), 'color', '#F88507', 'linewidth', 1.0); % Xe react
hold on 
% plot(((poisons(:,1)-zeroStamp)/time_conv), 1e-5*(poisons(:,5)/poisons(2,5)), 'color', '#F88507', 'linewidth', 1.0); % Sm react
% hold on 
% plot(feedbacks(:,1)-zeroStamp, 1e5*feedbacks(:,7), 'color', '#8F17E8', 'linewidth', 1.0); % 
% hold on 

title('Xenon Poison')
% lgd = legend('Xe Concentration', 'Sm Concentration', 'Xe Reactivity', 'Sm Reactivity'); %, 'Total');
lgd = legend('Xe Concentration', 'Xe Reactivity');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
% ylim([-110 110]);
% yticks(-125:25:125);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
yyaxis left
ylabel('Concentration (1/nominal)');
yyaxis right
ylabel('Reactivity (pcm)');
grid on

%% Samarium Graph
%subplot(2,2,2);
elseif plot_choice == 4
yyaxis left
% plot(((poisons(:,1)-zeroStamp)/time_conv), (poisons(:,2)/poisons(2,2)), 'color', '#1772e8', 'linewidth', 1.0); % Xe conc
% hold on
plot(((poisons(:,1)-zeroStamp)/time_conv), 0.000098+(poisons(:,3)/poisons(2,3)), 'color', '#1772e8', 'linewidth', 1.0); % Sm conc
hold on 
yyaxis right
% plot(((poisons(:,1)-zeroStamp)/time_conv), 1e-5*(poisons(:,4)/poisons(2,4)), 'color', '#F88507', 'linewidth', 1.0); % Xe react
% hold on 
plot(((poisons(:,1)-zeroStamp)/time_conv), (1e-5*(poisons(:,5)/poisons(2,5))-4.158), 'color', '#F88507', 'linewidth', 1.0); % Sm react
hold on 
% plot(feedbacks(:,1)-zeroStamp, 1e5*feedbacks(:,7), 'color', '#8F17E8', 'linewidth', 1.0); % 
% hold on 

title('Samarium Poison')
lgd = legend('Sm Concentration', 'Sm Reactivity'); %, 'Total');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
yyaxis left
ylabel('Concentration (1/nominal)');
% ylim([0.9984 1.0002]);
% yticks(0.9984:0.0004:1.0002);
yyaxis right
ylabel('Reactivity (pcm)');
grid on

%% Turbines Graph
%subplot(2,1,2);
else plot_choice == 5
plot(((turbines(:,1)-zeroStamp)/time_conv), turbines(:,2), 'color', '#F88507', 'linewidth', 1.0); % LPT
hold on 
plot(((turbines(:,1)-zeroStamp)/time_conv), turbines(:,3), 'color', '#07F885', 'linewidth', 1.0); % HPT
hold on 
plot(((turbines(:,1)-zeroStamp)/time_conv), (turbines(:,2)+turbines(:,3)), 'color', '#8507F8', 'linewidth', 1.0); % Total
hold on 

title('Turbine Power')
lgd = legend('Low Pressure', 'High Pressure', 'Total');
xlim([(start_plot/time_conv) (plot_width/time_conv)]);
xticks((start_plot/time_conv):(time_step/time_conv):(plot_width/time_conv));
% ylim([560 780]);
% yticks(560:20:780);
if time_unit == 0 
    xlabel('Time (sec)');
end
if time_unit == 1
    xlabel('Time (min)');
end
if time_unit == 2 
    xlabel('Time (hour)');
end
if time_unit == 3
    xlabel('Time (day)');
end
ylabel('Power (MW_{e})');
grid on
end



















